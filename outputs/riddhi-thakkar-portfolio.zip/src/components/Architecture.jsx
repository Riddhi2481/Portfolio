import { motion } from 'framer-motion';
import { FaArrowRight } from 'react-icons/fa';
import { architectureLayers } from '../data/portfolio';
import { Section } from './Section';

export function Architecture() {
  return (
    <Section
      id="architecture"
      eyebrow="Backend Architecture"
      title="A practical view of how Riddhi thinks about backend systems."
      description="An architecture showcase for API ownership, service boundaries, persistence, security, and microservices communication."
      className="bg-white dark:bg-ink"
    >
      <div className="grid gap-8 lg:grid-cols-[0.95fr_1.05fr]">
        <div className="card rounded-lg p-5">
          <div className="aspect-[4/3] overflow-hidden rounded-md">
            <img src="/assets/backend-architecture-hero.png" alt="Backend architecture diagram visual" className="h-full w-full object-cover" />
          </div>
        </div>

        <div className="grid gap-4">
          {architectureLayers.map((layer, index) => (
            <motion.div
              key={layer.title}
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.48, delay: index * 0.07 }}
              className="group flex items-center gap-4 rounded-lg border border-slate-200 bg-slate-50 p-4 transition hover:-translate-y-1 hover:border-royal hover:bg-white dark:border-white/10 dark:bg-panel/70 dark:hover:border-skyline dark:hover:bg-panel"
            >
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-md bg-white text-xl text-royal shadow-sm dark:bg-white/10 dark:text-skyline">
                <layer.icon />
              </span>
              <div className="min-w-0 flex-1">
                <h3 className="font-extrabold text-ink dark:text-paper">{layer.title}</h3>
                <p className="mt-1 text-sm leading-6 text-slate-600 dark:text-slate-300">{layer.detail}</p>
              </div>
              <FaArrowRight className="hidden shrink-0 text-slate-300 transition group-hover:translate-x-1 group-hover:text-royal sm:block dark:text-slate-600 dark:group-hover:text-skyline" />
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  );
}
