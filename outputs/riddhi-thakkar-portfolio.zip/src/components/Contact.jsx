import { FaEnvelope, FaLocationDot, FaPhone } from 'react-icons/fa6';
import { profile, socialLinks } from '../data/portfolio';
import { Section } from './Section';

export function Contact() {
  const contacts = [
    ['Email', profile.email, FaEnvelope, `mailto:${profile.email}`],
    ['Phone', profile.phone, FaPhone, `tel:${profile.phone.replace(/\s/g, '')}`],
    ['Location', profile.location, FaLocationDot, '#home']
  ];

  return (
    <Section
      id="contact"
      eyebrow="Contact"
      title="Ready to discuss backend Java opportunities."
      description="Use the form or direct links to connect about Java, Spring Boot, REST API, MySQL, or enterprise backend roles."
      className="bg-white dark:bg-ink"
    >
      <div className="grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
        <div className="space-y-4">
          {contacts.map(([label, value, Icon, href]) => (
            <a key={label} href={href} className="card focus-ring flex items-center gap-4 rounded-lg p-5 transition hover:-translate-y-1 hover:border-royal dark:hover:border-skyline">
              <span className="grid h-12 w-12 place-items-center rounded-md bg-slate-100 text-royal dark:bg-white/10 dark:text-skyline">
                <Icon />
              </span>
              <span>
                <span className="block text-sm font-semibold text-slate-500 dark:text-slate-400">{label}</span>
                <span className="block break-all font-extrabold text-ink dark:text-paper">{value}</span>
              </span>
            </a>
          ))}
          <div className="flex gap-2 pt-2">
            {socialLinks.map(({ label, href, icon: Icon }) => (
              <a key={label} href={href} aria-label={label} className="focus-ring grid h-12 w-12 place-items-center rounded-md bg-slate-100 text-slate-700 transition hover:bg-royal hover:text-white dark:bg-panel dark:text-slate-200 dark:hover:bg-skyline dark:hover:text-ink">
                <Icon />
              </a>
            ))}
          </div>
        </div>

        <form className="card rounded-lg p-6 sm:p-8" onSubmit={(event) => event.preventDefault()}>
          <div className="grid gap-5 sm:grid-cols-2">
            <label className="grid gap-2 text-sm font-bold text-slate-700 dark:text-slate-200">
              Name
              <input className="focus-ring rounded-md border border-slate-200 bg-white px-4 py-3 font-medium text-ink dark:border-white/10 dark:bg-ink dark:text-paper" type="text" placeholder="Your name" />
            </label>
            <label className="grid gap-2 text-sm font-bold text-slate-700 dark:text-slate-200">
              Email
              <input className="focus-ring rounded-md border border-slate-200 bg-white px-4 py-3 font-medium text-ink dark:border-white/10 dark:bg-ink dark:text-paper" type="email" placeholder="you@example.com" />
            </label>
          </div>
          <label className="mt-5 grid gap-2 text-sm font-bold text-slate-700 dark:text-slate-200">
            Subject
            <input className="focus-ring rounded-md border border-slate-200 bg-white px-4 py-3 font-medium text-ink dark:border-white/10 dark:bg-ink dark:text-paper" type="text" placeholder="Backend Java Developer role" />
          </label>
          <label className="mt-5 grid gap-2 text-sm font-bold text-slate-700 dark:text-slate-200">
            Message
            <textarea className="focus-ring min-h-36 rounded-md border border-slate-200 bg-white px-4 py-3 font-medium text-ink dark:border-white/10 dark:bg-ink dark:text-paper" placeholder="Share the opportunity details" />
          </label>
          <button type="submit" className="focus-ring mt-6 w-full rounded-md bg-royal px-5 py-3 text-sm font-extrabold text-white transition hover:-translate-y-0.5 hover:bg-blue-700 dark:bg-skyline dark:text-ink dark:hover:bg-cyan-300">
            Send Message
          </button>
        </form>
      </div>
    </Section>
  );
}
