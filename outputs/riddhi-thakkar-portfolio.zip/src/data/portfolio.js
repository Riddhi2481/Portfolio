import {
  FaGithub,
  FaLinkedin,
  FaEnvelope,
  FaJava,
  FaDatabase,
  FaShieldAlt,
  FaCodeBranch,
  FaServer,
  FaProjectDiagram
} from 'react-icons/fa';
import { SiSpringboot, SiMysql, SiPostman, SiSwagger, SiHibernate } from 'react-icons/si';

export const profile = {
  name: 'Riddhi Thakkar',
  title: 'Backend Java Developer',
  experience: '2 Years',
  company: 'Ananta Services',
  location: 'Gujarat, India',
  email: 'riddhi.thakkar@example.com',
  phone: '+91 98765 43210',
  resume: '/Riddhi_Thakkar_Resume.pdf',
  summary:
    'Results-driven Backend Java Developer with 2 years of experience designing, developing, and maintaining scalable enterprise applications with Java, Spring Boot, REST APIs, Microservices, MySQL, Hibernate/JPA, and secure authentication mechanisms.',
  objective:
    'Focused on building reliable backend architectures, fast data access layers, secure API ecosystems, and maintainable services that help product teams ship confidently.'
};

export const navItems = [
  ['About', 'about'],
  ['Skills', 'skills'],
  ['Experience', 'experience'],
  ['Projects', 'projects'],
  ['Architecture', 'architecture'],
  ['Contact', 'contact']
];

export const skillBars = [
  ['Java', 90, FaJava],
  ['Spring Boot', 85, SiSpringboot],
  ['REST APIs', 90, FaServer],
  ['MySQL', 85, SiMysql],
  ['Hibernate/JPA', 80, SiHibernate],
  ['Microservices', 75, FaProjectDiagram],
  ['Git/GitHub', 85, FaGithub],
  ['JWT Security', 80, FaShieldAlt]
];

export const skillGroups = [
  {
    title: 'Backend Development',
    items: ['Java', 'Spring Boot', 'Spring MVC', 'Spring Security', 'Spring Data JPA', 'Hibernate', 'RESTful APIs', 'Microservices Architecture']
  },
  {
    title: 'Database',
    items: ['MySQL', 'SQL', 'Database Design', 'Query Optimization']
  },
  {
    title: 'Security',
    items: ['JWT Authentication', 'RBAC', 'Authentication', 'Authorization']
  },
  {
    title: 'Tools & Methods',
    items: ['Git', 'GitHub', 'Postman', 'Maven', 'Swagger/OpenAPI', 'Eclipse', 'IntelliJ IDEA', 'Agile', 'Scrum', 'SDLC', 'Code Review', 'Debugging']
  }
];

export const experience = [
  {
    company: 'Ananta Services',
    role: 'Backend Java Developer',
    duration: 'July 2024 - Present',
    achievements: [
      'Developed enterprise-level backend applications using Java and Spring Boot.',
      'Designed RESTful APIs consumed by frontend applications and external services.',
      'Implemented JWT authentication, authorization, and role-based access control.',
      'Optimized MySQL schemas and complex SQL queries for performance and scale.',
      'Collaborated with frontend, QA, and business teams through Agile sprint cycles.'
    ]
  }
];

export const projects = [
  {
    title: 'Interview Management System',
    category: 'Enterprise',
    image: '/assets/backend-architecture-hero.png',
    description:
      'Backend platform for candidate management, interview scheduling, access control, authentication, and structured hiring workflows.',
    stack: ['Java', 'Spring Boot', 'MySQL', 'REST API', 'JWT'],
    features: ['Candidate Management', 'Interview Scheduling', 'RBAC', 'Authentication & Authorization', 'Database Management'],
    responsibilities: ['Developed complete backend architecture', 'Designed RESTful APIs', 'Implemented secure login functionality', 'Optimized database relationships and queries'],
    github: 'https://github.com/',
    demo: '#contact'
  },
  {
    title: 'Task Management System',
    category: 'Productivity',
    image: '/assets/backend-architecture-hero.png',
    description:
      'Task collaboration backend with task assignment, status tracking, dashboard analytics, user management, and secure authentication.',
    stack: ['Java', 'Spring Boot', 'MySQL', 'JavaScript'],
    features: ['Task Creation', 'Status Tracking', 'Dashboard Analytics', 'User Management', 'Secure Authentication'],
    responsibilities: ['Developed backend services', 'Implemented CRUD operations', 'Created REST APIs', 'Managed database design and optimization'],
    github: 'https://github.com/',
    demo: '#contact'
  }
];

export const architectureLayers = [
  { title: 'Java', detail: 'Core business logic and domain services', icon: FaJava },
  { title: 'Spring Boot', detail: 'Production-ready service runtime', icon: SiSpringboot },
  { title: 'REST APIs', detail: 'Clean contracts for frontend and third-party integrations', icon: FaServer },
  { title: 'Database Layer', detail: 'MySQL schemas, JPA repositories, optimized queries', icon: FaDatabase },
  { title: 'Security Layer', detail: 'JWT, RBAC, authentication and authorization flows', icon: FaShieldAlt },
  { title: 'Microservices', detail: 'Service-to-service communication and modular scaling', icon: FaCodeBranch }
];

export const education = {
  degree: "Bachelor's Degree in Computer Engineering",
  certifications: ['Java Programming Certification', 'Spring Boot Development Certification', 'SQL & Database Management Certification']
};

export const socialLinks = [
  { label: 'GitHub', href: 'https://github.com/', icon: FaGithub },
  { label: 'LinkedIn', href: 'https://www.linkedin.com/', icon: FaLinkedin },
  { label: 'Email', href: `mailto:${profile.email}`, icon: FaEnvelope }
];
